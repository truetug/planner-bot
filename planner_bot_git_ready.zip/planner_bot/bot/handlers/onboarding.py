from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import CommandStart
from bot.states import Onboarding

def register_handlers(dp: Dispatcher):
    dp.register_message_handler(start_onboarding, CommandStart(), state="*")
    dp.register_message_handler(set_style, state=Onboarding.style)
    dp.register_message_handler(set_gender, state=Onboarding.gender)
    dp.register_message_handler(set_comm_time, state=Onboarding.comm_time)
    dp.register_message_handler(set_context, state=Onboarding.planning_context)
    dp.register_message_handler(set_categories, state=Onboarding.planning_categories)
    dp.register_message_handler(set_status_freq, state=Onboarding.status_frequency)

async def start_onboarding(message: types.Message, state: FSMContext):
    await message.answer("Привет! Какой стиль общения тебе ближе?\n👉 дружеский / наставник / начальник")
    await Onboarding.style.set()

async def set_style(message: types.Message, state: FSMContext):
    await state.update_data(style=message.text)
    await message.answer("Какой у тебя пол? (м/ж)")
    await Onboarding.gender.set()

async def set_gender(message: types.Message, state: FSMContext):
    await state.update_data(gender=message.text)
    await message.answer("Когда тебе удобно, чтобы я напоминал? (утро/день/вечер)")
    await Onboarding.comm_time.set()

async def set_comm_time(message: types.Message, state: FSMContext):
    await state.update_data(comm_time=message.text)
    await message.answer("Когда тебе удобно планировать? Например, 'за завтраком' или 'перед сном'")
    await Onboarding.planning_context.set()

async def set_context(message: types.Message, state: FSMContext):
    await state.update_data(planning_context=message.text)
    await message.answer("По каким пунктам планировать? Напиши через запятую: работа, личное, проект А...")
    await Onboarding.planning_categories.set()

async def set_categories(message: types.Message, state: FSMContext):
    await state.update_data(planning_categories=[s.strip() for s in message.text.split(",")])
    await message.answer("Как часто спрашивать статус? Например: 1 раз в день, каждые 3 часа и т.п.")
    await Onboarding.status_frequency.set()

async def set_status_freq(message: types.Message, state: FSMContext):
    await state.update_data(status_frequency=message.text)
    data = await state.get_data()
    await message.answer("✅ Всё сохранено! Я начну с тобой работать по этим настройкам.")
    print("User config:", data)
    await state.finish()
