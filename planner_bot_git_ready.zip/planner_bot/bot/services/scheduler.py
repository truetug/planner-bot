def start_scheduler(dp):
    print("Запуск планировщика (заглушка)")
