from aiogram.dispatcher.filters.state import State, StatesGroup

class Onboarding(StatesGroup):
    style = State()
    gender = State()
    comm_time = State()
    planning_context = State()
    planning_categories = State()
    status_frequency = State()
    done = State()
