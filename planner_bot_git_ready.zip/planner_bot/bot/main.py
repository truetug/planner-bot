from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from aiogram.contrib.fsm_storage.memory import MemoryStorage
import logging
import os

from handlers import onboarding
from services.scheduler import start_scheduler

API_TOKEN = os.getenv("BOT_TOKEN")

logging.basicConfig(level=logging.INFO)

storage = MemoryStorage()
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot, storage=storage)

onboarding.register_handlers(dp)

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.answer("Привет! Давай начнём настройку твоего персонального планировщика.")

if __name__ == "__main__":
    start_scheduler(dp)
    executor.start_polling(dp, skip_updates=True)
